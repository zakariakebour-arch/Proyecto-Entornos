Litespeed Font License Agreement - Donationware

Copyright © Tiago Sá 2023
All rights reserved.

This font is free for personal, educational, non-profit, and charitable use.
For commercial use, please consider donating any amount via PayPal: tiagosa@i-am-tiago.com

Every contribution helps me continue creating free fonts. Thank you!

If you have any questions, feel free to reach out:
Email: hi@i-am-tiago.com

Redistribution of this font is permitted only in its original, unmodified form and with this license included.